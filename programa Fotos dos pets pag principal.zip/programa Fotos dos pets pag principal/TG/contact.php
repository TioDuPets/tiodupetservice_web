<?php
// contact.php
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Sobre - Tio Du Pets</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1> Tio Du Pets</h1>
        <nav>
            <a href="index.php">Início</a>
            <a href="about.php">Sobre</a>
            <a href="contact.php">Contato</a>
            <a href="add_pet.php">Adicionar Pet</a>
        </nav>
    </header>
    <main>
        <h2>Adicionar Contato</h2>
        <?php if (isset($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form method="POST" action="add_pet.php">
            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" required>
            <label for="type">Tipo:</label>
            <input type="text" id="type" name="type" required>
            <button type="submit">Adicionar</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Tio Du Pets</p>
    </footer>
</body>
</html>
