<?php
// Configurações de conexão com o banco de dados
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'dogadventure');
function getDbConnection() {
    // Cria a conexão usando mysqli
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    // Verifica a conexão
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}
function getPet() {
    // Conecta ao banco de dados
    $conn = getDbConnection();
    // Prepara a consulta SQL usando prepared statements
    $stmt = $conn->prepare("SELECT name, type FROM pet ORDER BY name");
    // Executa a consulta
    $stmt->execute();
    // Obtém os resultados
    $result = $stmt->get_result();
    // Armazena os resultados em um array
    $pets = [];
    while ($row = $result->fetch_assoc()) {
        $pet[] = $row;
    }
    // Fecha a declaração e a conexão
    $stmt->close();
    $conn->close();
    return $pet;
}
