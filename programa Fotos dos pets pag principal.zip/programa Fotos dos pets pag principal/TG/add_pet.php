<?php
// add_pet.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $type = trim($_POST['type'] ?? '');
    $type = trim($_POST['image'] ?? '');
    if ($name && $type && $image) {
        $pet = json_decode(file_get_contents('pets.json'), true);
        $new_pet = [
            'id' => count($pets) + 1,
            'name' => $name,
            'type' => $type,
            'image' => $image
        ];
        $pet[] = $new_pet;
        file_put_contents('pets.json', json_encode($pet, JSON_PRETTY_PRINT));
        header('Location: index.php');
        exit;
    } else {
        $error = "Por favor, preencha todos os campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Pet - Tio Du Pets</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1> Tio Du Pets</h1>
        <nav>
            <a href="index.php">Início</a>
            <a href="about.php">Sobre</a>
            <a href="contact.php">Contato</a>
            <a href="add_pet.php">Adicionar Pet</a>
        </nav>
    </header>
    <main>
        <h2>Adicionar Novo Pet</h2>
        <?php if (isset($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form method="POST" action="add_pet.php">
            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" required>
            <label for="type">Tipo:</label>
            <input type="text" id="type" name="type" required>
             <label for="type">Imagem:</label>
            <input type="text" id="type" name="image" required>
            <button type="submit">Adicionar</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Tio Du Pets</p>
    </footer>
</body>
</html>
