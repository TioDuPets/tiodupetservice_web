<?php
// index.php
$pet = json_decode(file_get_contents('pets.json'), true);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Tio Du Pets</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1> Tio Du Pets</h1>
        <nav>
            <a href="index.php">Início</a>
            <a href="about.php">Sobre</a>
            <a href="contact.php">Contato</a>
            <a href="add_pet.php">Adicionar Pet</a>
        </nav>
    </header>
    <main>
        <h2>Nossos Pets</h2>
        <div class="pet">
            <?php foreach ($pet as $pet): ?>
                <div class="pet">
                    <h3><?php echo htmlspecialchars($pet['name']); ?></h3>
                    <p>Tipo: <?php echo htmlspecialchars($pet['type']); ?></p>
                    <p>Imagem: <?php echo htmlspecialchars($pet['image']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Tio Du Pets</p>
    </footer>
</body>
</html>
