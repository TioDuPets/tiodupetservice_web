<?php
// about.php
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Sobre - Tio Du Pets</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1> Tio Du Pets</h1>
        <nav>
            <a href="index.php">Início</a>
            <a href="about.php">Sobre</a>
            <a href="contact.php">Contato</a>
            <a href="add_pet.php">Adicionar Pet</a>
        </nav>
    </header>
    <main>
        <h2>Sobre Nós</h2>
        <p>Bem-vindo ao Tio Du Pets! Somos apaixonados por cães e queremos proporcionar as melhores oportunidades para os seus pets.</p>
    </main>
    <footer>
        <p>&copy; 2024 Tio Du Pets</p>
    </footer>
</body>
</html>
